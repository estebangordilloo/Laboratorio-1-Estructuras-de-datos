package interfaz;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class TorresDeHanoiPanel extends JPanel {

    private final Stack<Integer>[] torres;
    private final List<Color> discoColores;
    private int movimientos;

    @SuppressWarnings("unchecked")
    public TorresDeHanoiPanel(int numDiscos) {
        this.torres = new Stack[3];
        this.discoColores = new ArrayList<>();
        this.movimientos = 0;

        for (int i = 0; i < 3; i++) {
            torres[i] = new Stack<>();
        }

        for (int i = numDiscos; i > 0; i--) {
            torres[0].push(i);
            discoColores.add(new Color((int) (Math.random() * 0x1000000)));
        }

        setPreferredSize(new Dimension(700, 380));
        setBackground(Color.WHITE);
        setDoubleBuffered(true);
    }

    public void moverDisco(int origen, int destino) {
        if (!torres[origen].isEmpty()) {
            int disco = torres[origen].pop();
            torres[destino].push(disco);
            movimientos++;
            // Asegurar actualización en el EDT
            SwingUtilities.invokeLater(this::repaint);
        } else {
            System.err.println("Error: intento de mover disco desde torre vacía (" + origen + ")");
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int ancho = getWidth();
        int alto = getHeight();

        // Base
        g.setColor(new Color(220, 220, 220));
        g.fillRect(0, alto - 40, ancho, 40);

        int torreWidth = ancho / 4;
        int torreHeight = alto - 100;
        int discoHeight = 20;

        for (int i = 0; i < 3; i++) {
            int torreX = (i + 1) * torreWidth - torreWidth / 2;
            int torreY = alto - 40 - torreHeight;

            // Poste
            g.setColor(Color.DARK_GRAY);
            g.fillRect(torreX - 5, torreY, 10, torreHeight);

            // Discos (dibujar de abajo hacia arriba)
            int discoY = alto - 40 - discoHeight;
            for (int disco : torres[i]) {
                int discoWidth = disco * 20;
                int discoX = torreX - discoWidth / 2;
                g.setColor(discoColores.get(disco - 1));
                g.fillRoundRect(discoX, discoY, discoWidth, discoHeight, 10, 10);
                g.setColor(Color.BLACK);
                g.drawRoundRect(discoX, discoY, discoWidth, discoHeight, 10, 10);
                discoY -= discoHeight;
            }
        }

        g.setColor(Color.BLACK);
        g.drawString("Movimientos: " + movimientos, 10, 20);
    }

    public void reiniciar(int numDiscos) {
        movimientos = 0;
        for (int i = 0; i < 3; i++) {
            torres[i].clear();
        }
        discoColores.clear();

        for (int i = numDiscos; i > 0; i--) {
            torres[0].push(i);
            discoColores.add(new Color((int) (Math.random() * 0x1000000)));
        }
        repaint();
    }
}
