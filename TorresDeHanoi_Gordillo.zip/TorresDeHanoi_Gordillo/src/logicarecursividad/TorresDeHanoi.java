package logicarecursividad;
import interfaz.TorresDeHanoiPanel;

public class TorresDeHanoi {
    private final TorresDeHanoiPanel panel;

    public TorresDeHanoi(TorresDeHanoiPanel panel) {
        this.panel = panel;
    }

    public void resolver(int n, int origen, int auxiliar, int destino, int delay) {
        if (n <= 0) return;

        resolver(n - 1, origen, destino, auxiliar, delay);

        panel.moverDisco(origen, destino);
        try {
            Thread.sleep(delay);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        resolver(n - 1, auxiliar, origen, destino, delay);
    }
}
